import java.util.Scanner;

public class Drone {
	int xAxis;
	int yAxis;
	int zAxis;
	String direction;
	String coords;
	Scanner s = new Scanner(System.in);
	
	public Drone(int x, int y, int z) 
	{
		xAxis = x;
		yAxis = y;
		zAxis = z;
	}
	
	String positionChange(String dirType2)
	{
		direction = dirType2;
		
		switch(direction)
		{
		case "Forward":
		{
			zAxis += 1;
			break;
		}
		
		case "Backward":
		{
			zAxis -= 1;
			break;
		}
		
		case "Left":
		{
			xAxis -= 1;
			break;
		}
		
		case "Right":
		{
			xAxis +=1;
			break;
		}
		
		case "Up":
		{
			yAxis +=1;
			break;
		}
		
		case "Down":
		{
			yAxis -= 1;
			break;
		}

		}
		
		coords = xAxis + "," + yAxis + "," + zAxis;
		return coords;
	}
	
	
	int getX()
	{
		int xVal;
		xVal = xAxis;
		return xVal;
	}
	
	int getY()
	{
		int yVal;
		yVal = yAxis;
		return yVal;
	}
	
	
	int getZ()
	{
		int zVal;
		zVal = zAxis;
		return zVal;
	}


}
