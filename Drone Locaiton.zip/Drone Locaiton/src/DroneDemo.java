
public class DroneDemo 
{
	static int x;
	static int y;
	static int z;
	static boolean stop;
	String directionType;
	String coords;
	public DroneDemo(String dir)
	{
		directionType = dir;
	}
	
	public void main(String[] args) 
	{

		Drone drone1 = new Drone(x, y, z);
        coords = drone1.positionChange(directionType);
		x = drone1.getX();
		y = drone1.getY();
		z = drone1.getZ();
	}
	
	

}
